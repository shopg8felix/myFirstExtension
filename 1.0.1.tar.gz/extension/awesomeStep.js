module.exports = async (context, input) => {
  // Put your own code here
}

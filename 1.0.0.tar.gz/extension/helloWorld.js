module.exports = function (context, input, callback) {
    const message = 'Hello World'
    callback(null, { message: message })
  }